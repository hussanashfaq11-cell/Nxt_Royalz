<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Error</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<script type="e02484a970bf5b8dc9a9d81d-text/javascript">
        function goHome() {
           window.location.href='/';
        }
    </script>
<style type="text/css">
        html,body{
            background-color: #00eeff;
            color: #fff;
        }
        .main{
            text-align: center;
            margin-top: 10rem;
        }
        .btn {
            width: 300px;
            height: 60px;
            color: rgba(255,255,255,.6);
            border: 2px solid #00eeff;
            background-color: rgba(27,37,83,0.6);
            font-size: 24px;
            border-radius: 8px;
            cursor: pointer;
        }
        .img{
            margin-bottom: 60px;
        }
        .h1{
            font-size: 36px;margin-bottom: 20px;
        }
        .txt{
            font-size: 20px;margin-bottom: 60px;
            color: #fff;
        }
    </style>
<script async src='/cdn-cgi/bm/cv/669835187/api.js'></script></head>
<body>
<div class="main">
<script type="text/javascript" style="display:none">
//<![CDATA[
window.__mirage2 = {petok:"34b33e236d910a10da6299e747be4e92b22e4b4d-1625831579-1800"};
//]]>
</script>
<script type="text/javascript" src="https://ajax.cloudflare.com/cdn-cgi/scripts/04b3eb47/cloudflare-static/mirage2.min.js"></script>
<img data-cfsrc="//midas.gtimg.cn/oversea_web/images/error.png" class="img" style="display:none;visibility:hidden;"><noscript><img src="//midas.gtimg.cn/oversea_web/images/error.png" class="img"></noscript>
<h1 class="h1">Error</h1>
<p class="txt">Sorry, the page you viewed is not found!</p>
<button class="btn" type="button" onclick="if (!window.__cfRLUnblockHandlers) return false; goHome()" data-cf-modified-e02484a970bf5b8dc9a9d81d-="">Home Page</button>
</div>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="e02484a970bf5b8dc9a9d81d-|49" defer=""></script>

</body>
</html>